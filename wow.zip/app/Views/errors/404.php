<html lang="en">
<head><meta charset="UTF-8"><title>404 Not Found</title></head>
<body><h1>404 - Page Not Found</h1><a href="/">Go Home</a></body>